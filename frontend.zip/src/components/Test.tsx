import * as React from 'react';

class Test extends React.Component {
public render() {
    return (
      <div>
        <h1>Testing</h1>
        <button className="btn btn-primary">Click Here</button>
      </div>
    )
  }
}

export default Test
