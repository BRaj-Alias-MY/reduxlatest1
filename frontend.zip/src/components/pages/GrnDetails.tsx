import * as React  from 'react'

class GrnDetails extends React.Component {
 public render() {
    return (
      <div>
      <h2>  this is grn details comp </h2>
      </div>
    )
  }
}

export default GrnDetails
