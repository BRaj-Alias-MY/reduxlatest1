import * as React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './assets/css/style.css';
import Grn from './components/pages/Grn';
import { Route, NavLink , BrowserRouter, Switch } from 'react-router-dom';
import GrnDetails from './components/pages/GrnDetails';

export default class Main extends React.Component {
  public render() {
    return (
      <BrowserRouter>

        <React.Fragment>

          <nav className="navbar navbar-expand-lg navbar-light bg-dark">
            <NavLink className="navbar-brand" to="/">GRN</NavLink>
            <button
              className="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarText"
              aria-controls="navbarText"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon" />
            </button>
            <div className="collapse navbar-collapse" id="navbarText">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item">
                  <NavLink className="nav-link" to="/">POs</NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className="nav-link" to="/grndetails">
                    GRN Details
                  </NavLink>
                </li>
                
                <li className="nav-item">
                  <NavLink className="nav-link" to="/Contact">Contact</NavLink>
                </li>

                <li className="nav-item">
                  <NavLink className="nav-link" to="/context">
                    ContextAPI
                  </NavLink>
                </li>

              </ul>
              <span className="navbar-text">
                <NavLink className="nav-link" to="/Logout">Logout</NavLink>
              </span>
            </div>
          </nav>

          <div className="container-fluid">
            <div className="row">
              <div className="col-md-12">
                <div className="content">
                  <Switch>
                    <Route exact path="/" component={Grn} />
                    <Route path="/grndetails" component={GrnDetails} />
                   
                    <Route component={Grn} />
                  </Switch>
                </div>
              </div>
              

            </div>

          </div>

        </React.Fragment>

      </BrowserRouter>
    )
  }
}
