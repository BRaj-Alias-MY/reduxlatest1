import { Entity, Column} from 'typeorm';
import { BaseEntity } from './BaseEntity';

@Entity()
export class POSEntity extends BaseEntity {

    @Column({ length: 300 })
    item: string;
    @Column({ length: 300 })
    item_name: string;
    @Column()
    item_desc: string;
    @Column()
    po_no: number;
    @Column()
    batch_no: number;  
    @Column()
    lot_no: number;  
    @Column()
    barcode_number: number;  
}