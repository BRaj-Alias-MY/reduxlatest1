import { Entity, Column} from 'typeorm';
import { BaseEntity } from './BaseEntity';

@Entity()
export class PostEntity extends BaseEntity {

    @Column({ length: 300 })
    title: string;
      
}