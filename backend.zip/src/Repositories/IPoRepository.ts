import {PosDto} from '../Dtos/Pos.dto';

export interface IPosRepository {
 FindAll(): Promise<PosDto[]>;
}