import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { POSEntity } from  '../Models/PosEntity.entity'
import { PosDto } from  '../Dtos/Pos.dto'
import { IPosRepository } from 'src/Repositories/IPoRepository';

@Injectable()
export class PosService implements IPosRepository{

    constructor(@InjectRepository(POSEntity) private posRepository: Repository<POSEntity>) { }
    async FindAll(): Promise<PosDto[]> {
        return await this.posRepository.find();
    }
    
}
