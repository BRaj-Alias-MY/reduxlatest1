import { Controller, Post, Body, Get, Put, Delete, Param } from '@nestjs/common';
import { PosService } from '../Services/PosRepository.service'

@Controller('grn')
export class PosController {

    constructor(private service: PosService) { }


    @Get('/all')
    get() {
        return this.service.FindAll();
    }
   

}